export const ADD_OR_REMOVE_SELECTED_ROWS = 'zeroList/add_or_remove_selected_rows'
export const INIT_MULTI_SELECT = 'zeroList/initMultiSelect'
export const INIT_LIST = 'zeroList/init_list'